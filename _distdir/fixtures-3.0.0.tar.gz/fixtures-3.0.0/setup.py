#!/usr/bin/env python

import setuptools

setuptools.setup(
    setup_requires=['pbr>0.11'],
    pbr=True)
